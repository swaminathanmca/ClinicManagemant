package com.lissomsoft.clinic.controller;

import com.lissomsoft.clinic.service.UserServiceImpl;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.lissomsoft.clinic.domain.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.Iterator;
import java.util.List;

import com.lissomsoft.clinic.service.UserService;


@Controller
@Component

public class HelloController {
    //@Autowired Patient patient;
    @Autowired(required = false)
    private UserService userService;

    public void setUserService(UserService userService) {
        this.userService = userService;
    }


    @RequestMapping(value = "/")
    public String homePage(HttpServletRequest request) throws Exception {
        return "login";
    }


    @RequestMapping(value = "/GetPatient", method = RequestMethod.GET)
    public
    @ResponseBody
    String getPatient() throws JSONException {
    /*	model.addAttribute("message", "Hello world!");*/
        JSONArray jsonArray = new JSONArray();
        JSONObject mainObj = new JSONObject();
        JSONObject jsonObject = new JSONObject();
        Patient patient = new Patient();
        patient.setFullName("Jayaswaminathan");
        patient.setBloodGroup("AB");
        patient.setDob("24/07/1992");
        patient.setFactor("Positive");
        patient.setGender("Male");
        patient.setmStatus("Single");
        patient.setStatus("active");
        jsonObject.put("FullName", patient.getFullName());
        jsonObject.put("BloodGroup", patient.getBloodGroup());
        jsonObject.put("Dob", patient.getDob());
        jsonObject.put("Factor", patient.getFactor());
        jsonObject.put("Gender", patient.getGender());
        jsonObject.put("Mstatus", patient.getmStatus());
        jsonObject.put("Status", patient.getStatus());
        jsonArray.put(jsonObject);
        mainObj.put("Patient", jsonArray);
        return mainObj.toString();
    }

    @RequestMapping(value = "/SignIn", method = RequestMethod.POST)
    public
    @ResponseBody
    String signin(@RequestBody User user, HttpServletRequest request) throws JSONException {

        HttpSession session = request.getSession();
        //System.out.println("Hello"+user.toString());

        String message="Enter Correct Username And Password";
        List<User> userList;
        JSONObject jsonObject = new JSONObject();
        JSONObject data = new JSONObject();
        JSONObject status = new JSONObject();
        userList = userService.authenticateUser(user.getUsername(), user.getPassword());

        Iterator<User> it = userList.iterator();


        if (it.hasNext()) {
            while (it.hasNext()) {

                User userdetails = it.next();

                jsonObject.put("username", userdetails.getUsername());
                jsonObject.put("email_id", userdetails.getEmail_id());
                jsonObject.put("role_name", userdetails.getRole_name());
                data.put("data", jsonObject);
                status.put("status", true);

                data.put("status", true);

            }
        } else {
            data.put("status", false);
            data.put("message",message);
        }


        return data.toString();


    }

    @RequestMapping(value = "/dashboard")
    public String dashBoard(HttpServletRequest request) throws Exception {
        return "dashboard";
    }

}