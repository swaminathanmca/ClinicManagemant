/**
 * Created by Admin on 2/18/2017.
 */

app.controller('dashboard', function ($scope, $http,$window) {

    console.log($window.sessionStorage.role_name);

});